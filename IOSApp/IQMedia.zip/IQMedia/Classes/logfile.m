//
//  logfile.m
//  IQMedia
//
//  Created by Alliancetek on 15/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "logfile.h"
#import "Global.h"

@implementation logfile

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationController.navigationBar.hidden=NO;
    
    UIBarButtonItem *btnMail=[[UIBarButtonItem alloc] initWithTitle:@"Clean Log" style:UIBarButtonItemStyleBordered target:self action:@selector(cleanlog)];
    self.navigationItem.rightBarButtonItem=btnMail;
    [btnMail release];
    
    UIBarButtonItem *btnMail1=[[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStyleBordered target:self action:@selector(gotoback)];
    self.navigationItem.leftBarButtonItem=btnMail1;
    [btnMail1 release];
    
    NSString *strLog=@"";
    
    for (int i=0; i<[logarry count]; i++) {
        strLog=[strLog stringByAppendingFormat:@"%@",[logarry objectAtIndex:i]];
        strLog=[strLog stringByAppendingFormat:@"%@",@"<br/>"];
    }
    [objWebView loadHTMLString:strLog baseURL:nil];
    
    
}
- (void)gotoback{
    logback=TRUE;
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)cleanlog{
    [logarry removeAllObjects];
    NSString *strLog=@"";
    
    for (int i=0; i<[logarry count]; i++) {
        strLog=[strLog stringByAppendingFormat:@"%@",[logarry objectAtIndex:i]];
        strLog=[strLog stringByAppendingFormat:@"%@",@"\n\n"];
    }
    [objWebView loadHTMLString:strLog baseURL:nil];

}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
