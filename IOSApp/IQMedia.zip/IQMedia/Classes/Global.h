


#import	<MediaPlayer/MediaPlayer.h>


#define WEB_SERVICE_FULL_URL @"http://qaservices.iqmediacorp.com/iqsvc/Statskedprog/GetPlayerData?ID=7d714857-e1ca-40cf-949b-370e40c9de3d&Type=clip"


#define ProductionURL       @"http://qaservices.iqmediacorp.com/iossvc/GetVars?%@&IOSAppVer=%@" //if BaseURL=0
#define LiveURL             @"http://services.iqmediacorp.com/iossvc/GetVars?%@&IOSAppVer=%@"  // else BaseURL=1

#define logProductionURL    @"http://qaservices.iqmediacorp.com/svc/logs/logClipPlay?%@"
#define logLiveURL          @"http://services.iqmediacorp.com/svc/logs/logClipPlay?%@"

#define TAG_Media           @"Media"
#define TAG_MediaValid      @"IsValidMedia"
#define TAG_URL             @"url"
#define TAG_logURL          @"logurl"

#define AlertClipID         @"ClipID is temporarily unavailable."
#define AlertNewVersion     @"New version is available"
#define AlertHasExp         @"An error occurred, Please try again later"

#define TAG_AppVersion      @"CFBundleVersion"
#define TAG_OldVersion      @"IsOldVersion"
#define TAG_UpdateUrl       @"IOSAppUpdateUrl" 
#define TAG_HasException    @"HasException"

MPMoviePlayerController *videoPlayer;
NSMutableArray *logarry;
BOOL logback;
BOOL openURL;
