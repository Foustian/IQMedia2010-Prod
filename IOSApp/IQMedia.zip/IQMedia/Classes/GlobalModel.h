//
//  GlobalModel.h
//  EasyMedia
//
//  Created by Amultek Software on 14/04/11.
//  Copyright 2011 Amultek Software Solutions Pvt. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Reachability.h"



@interface GlobalModel : NSObject {
	
    
   
}
- (NSMutableArray *)WebServiceCalling:(NSString *)FunctionName:(NSString *)Parameter:(NSString *)ResponseNodeToRead;
-(void)logPrint:(NSString*)functionName;
-(void)clearnLog;
@end
