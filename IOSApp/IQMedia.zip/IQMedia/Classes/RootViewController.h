//
//  RootViewController.h
//  IQMedia
//
//  Created by Alliancetek on 24/05/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Global.h"
#import "GlobalModel.h"
#import	<MediaPlayer/MediaPlayer.h>
#import "BJRangeSliderWithProgress.h"

@interface RootViewController : UIViewController {
    
    //MPMoviePlayerController *videoPlayer;
    GlobalModel *objGlobal;
    UIInterfaceOrientation objOrientation;
    BJRangeSliderWithProgress *slider;
    IBOutlet UIToolbar *mToolbar;
    NSArray *data;
    BOOL loadLogFrist,loadFalseFrist;
          
}

@property (retain, nonatomic) MPMoviePlayerController *videoPlayer;
@property (retain, nonatomic) IBOutlet BJRangeSliderWithProgress *slider;
- (BOOL)CheckInternetConnectivity;
- (void)logsendtoServer;
- (void)gotoLogfile;
- (void)videoLinkPassToPlay;
@end
