//
//  GlobalModel.m
//  EasyMedia
//
//  Created by Amultek Software on 14/04/11.
//  Copyright 2011 Amultek Software Solutions Pvt. Ltd. All rights reserved.
//

#import "GlobalModel.h"
#import "TouchXML.h"
#import "Global.h"


@implementation GlobalModel


- (NSMutableArray *)WebServiceCalling:(NSString *)FunctionName:(NSString *)Parameter:(NSString *) ResponseNodeToRead {
    
    
    NSString *strWebServiceFullURL=nil;
    if ([ResponseNodeToRead isEqualToString:TAG_URL]) {
       strWebServiceFullURL=[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:TAG_URL]] ; 
    }else if([ResponseNodeToRead isEqualToString:TAG_logURL]){
        strWebServiceFullURL=[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:TAG_logURL]] ;
    }
    
   
    
//	NSString *strSOAPAction=[NSString stringWithFormat:@"%@/%@",strWebServiceFullURL,FunctionName] ;
//
	NSMutableArray *res = [[NSMutableArray alloc] init];
//	
//		
//	NSString *soapMessage =[NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
//							 "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
//							 "<soap:Body>\n"
//							 "<%@ xmlns='%@'>\n"
//							 "%@\n"
//							 "</%@>\n"
//							 "</soap:Body>\n"
//							 "</soap:Envelope>\n",FunctionName,strWebServiceFullURL,Parameter,FunctionName];

	

	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@", strWebServiceFullURL]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
    
    	
//	NSString *msgLength = [NSString stringWithFormat:@"%d", [soapMessage length]];
//	
//	[theRequest addValue: @"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
//	[theRequest addValue: strSOAPAction forHTTPHeaderField:@"SOAPAction"];
//	[theRequest addValue: msgLength forHTTPHeaderField:@"Content-Length"];
//	[theRequest setHTTPMethod:@"POST"];
//	[theRequest setHTTPBody: [soapMessage dataUsingEncoding:NSUTF8StringEncoding]];
	
	
	NSError *WSerror;
	NSURLResponse *WSresponse;
	
	
		
	
	NSData* webData = [NSURLConnection sendSynchronousRequest:theRequest
									returningResponse:&WSresponse 
												error:&WSerror];
		
	NSString *theXML = [NSString stringWithFormat:@"%.*s", [webData length], [webData bytes]];
//	theXML = [theXML stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"xmlns=\"%@\"",WEB_SERVICE_FULL_URL] withString:@""];

	
	
	CXMLDocument *doc	= [[[CXMLDocument alloc] initWithXMLString:theXML options:0 error:nil] autorelease];

	NSArray *nodes = NULL;
	//	searching for piglet nodes
	nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",@"Root"] error:nil]; // ResponseNodeToRead
	
	
	for (CXMLElement *node in nodes) {
		NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
		int counter;

		for(counter = 0; counter < [node childCount]; counter++) {
			if ([[node childAtIndex:counter] stringValue]!=nil) {
				[item setObject:[[node childAtIndex:counter] stringValue] forKey:[[node childAtIndex:counter] name]];
			}
			else {
				[item setObject:@"" forKey:[[node childAtIndex:counter] name]];
			}
		}
		[res addObject:item];
		[item release];
	}
	
	return res;
}

-(void)logPrint:(NSString*)functionName{
    
    
}
-(void)clearnLog{
    
  
}



@end