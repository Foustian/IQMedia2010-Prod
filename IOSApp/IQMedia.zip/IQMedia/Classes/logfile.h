//
//  logfile.h
//  IQMedia
//
//  Created by Alliancetek on 15/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface logfile : UIViewController
{
    IBOutlet UIWebView *objWebView;
}
@end
