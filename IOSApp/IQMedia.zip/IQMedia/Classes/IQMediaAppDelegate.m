//
//  IQMediaAppDelegate.m
//  IQMedia
//
//  Created by Alliancetek on 24/05/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "IQMediaAppDelegate.h"
#import "RootViewController.h"
#import "AVFoundation/AVAudioSession.h"

@implementation IQMediaAppDelegate

@synthesize window;
@synthesize navigationController;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
    
//    if ([logarry retainCount]==0) {
//        
//        logarry=[[NSMutableArray alloc]init];
//        
//    }   
//    [logarry addObject:@"didFinishLaunchingWithOptions"];
    
    
    openURL=FALSE;    
        
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:TAG_URL];
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:TAG_logURL];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
    [[AVAudioSession sharedInstance] setActive: YES error: nil];
    
    self.window.rootViewController = self.navigationController;
    [self.window makeKeyAndVisible];

    return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication annotation:(id)annotation 
{
    
//    if ([logarry retainCount]==0) {
//        logarry=[[NSMutableArray alloc]init];
//    }    
//   [logarry addObject:@"openURL"];
//    logback=FALSE; 
   // BOOL result;
    NSString *uRLString = [url absoluteString];
    uRLString=[uRLString stringByReplacingOccurrencesOfString:@"IQMedia://" withString:@""];
    uRLString=[uRLString stringByReplacingOccurrencesOfString:@"iqmedia://" withString:@""];
    
    if ([uRLString length]==0) {
        UIAlertView *objAlert=[[UIAlertView alloc]initWithTitle:@"IQMedia" message:AlertClipID delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];            
        [objAlert show];
        [objAlert release]; 
        [(RootViewController*)navigationController.visibleViewController videoPlayer].contentURL=nil;
        return NO;
    }
        
        
    NSLog(@"remove http:// =%@",uRLString);
    
    NSArray *strArry=[uRLString componentsSeparatedByString:@"&"];
    
    NSLog(@"array =%@",strArry);
    
    NSString *clipid=[strArry objectAtIndex:0];
    NSString *baseURL=[strArry objectAtIndex:1];
        
    
    NSString *logStrURL;
    NSString *logFid;
    logFid=clipid;
    logFid=[logFid stringByReplacingOccurrencesOfString:@"ClipID" withString:@"fid"];
    logFid=[logFid stringByReplacingOccurrencesOfString:@"Clipid" withString:@"fid"];
    logFid=[logFid stringByReplacingOccurrencesOfString:@"clipid" withString:@"fid"];
    logFid=[logFid stringByAppendingFormat:@"&ref=IOS"];
    
    NSString *existversion = [[[NSBundle mainBundle] infoDictionary] objectForKey:TAG_AppVersion];
    
    openURL=TRUE;
    if ([baseURL isEqualToString:@"baseurl=1"] || 
        [baseURL isEqualToString:@"baseurl=1/"] || 
        [baseURL isEqualToString:@"baseurl=1"] || 
        [baseURL isEqualToString:@"baseurl=1/"] || 
        [baseURL isEqualToString:@"BaseUrl=1"] || 
        [baseURL isEqualToString:@"BaseUrl=1/"] || 
        [baseURL isEqualToString:@"BaseUrl=1"] || 
        [baseURL isEqualToString:@"BaseUrl=1/"] ||
        [baseURL isEqualToString:@"BaseURL=1"] || 
        [baseURL isEqualToString:@"BaseURL=1/"]) {
        
        uRLString=[NSString stringWithFormat:ProductionURL,clipid,existversion];   
           
        logStrURL=[NSString stringWithFormat:logProductionURL,logFid];  
        
    }else{
        
        uRLString=[NSString stringWithFormat:LiveURL,clipid,existversion];
        
        logStrURL=[NSString stringWithFormat:logLiveURL,logFid];
    }        
             
        [[NSUserDefaults standardUserDefaults] setObject:logStrURL forKey:TAG_logURL];
            
        // mail URL
    
        [[NSUserDefaults standardUserDefaults] setObject:uRLString forKey:TAG_URL];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [(RootViewController*)navigationController.visibleViewController viewWillAppear:YES];
        

    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
    
//    [videoPlayer pause];
//    vr=videoPlayer.currentPlaybackRate;
//    vt=videoPlayer.currentPlaybackTime;
   
    
    NSLog(@"Pause in delegate");
    
    
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
    
   
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
//    NSLog(@"Play in delegate");
//    [videoPlayer setCurrentPlaybackRate:vr+2];
//    [videoPlayer setCurrentPlaybackTime:vt+2];   
//    
//    
//    [videoPlayer prepareToPlay];
//    [videoPlayer play];
}







- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:TAG_URL];
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:TAG_logURL];
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
	[navigationController release];
	[window release];
	[super dealloc];
}


@end

