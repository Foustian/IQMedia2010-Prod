//
//  RootViewController.m
//  IQMedia
//
//  Created by Alliancetek on 24/05/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import "Reachability.h"
#import "logfile.h"
#import "AVFoundation/AVAudioSession.h"


@implementation RootViewController
@synthesize slider;
@synthesize videoPlayer;

#pragma mark -InternetConnection

- (BOOL)CheckInternetConnectivity
{
    Reachability* reachability;
	
	@try {
        
		
		[[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(handleNetworkChange:) name: kReachabilityChangedNotification object: nil];
		reachability = [Reachability reachabilityForInternetConnection];
		
		[reachability startNotifier];
		NetworkStatus remoteHostStatus = [reachability currentReachabilityStatus];
		
		if(remoteHostStatus == NotReachable) {
			
			return FALSE;
		}
		else 
		{
			
			return TRUE;
		}
	}
	@catch (NSException * e) {
		NSLog(@"ERROR - CheckInternetConnectivity ->   %@, REASON -- > %@",[e name],[e reason]);
	}
	
	return FALSE;
	
}



#pragma mark View lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    self.navigationItem.title=@"IQMedia";
    
    loadLogFrist=FALSE;
    loadFalseFrist=FALSE;
    logback=FALSE;
    
    videoPlayer = [[MPMoviePlayerController alloc] init];
    videoPlayer.movieSourceType=MPMovieSourceTypeStreaming;
    videoPlayer.controlStyle=MPMovieControlStyleEmbedded;
   // videoPlayer.contentURL=[NSURL URLWithString:@"http://www.encoding.com/video/demo.mp4"];  
   // [videoPlayer play];
 
   [self.view addSubview:videoPlayer.view];    
             
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(moviePlaybackComplete:) name:MPMoviePlayerLoadStateDidChangeNotification object:videoPlayer];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(moviePlaybackComplete:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification object:videoPlayer];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(moviePlaybackComplete:)
                                                 name:MPMoviePlayerNowPlayingMovieDidChangeNotification object:videoPlayer];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(movieFinish:)
                                                 name:MPMoviePlayerPlaybackStateDidChangeNotification object:videoPlayer];
    
    objGlobal=[GlobalModel new];
   
    
    
    
//    UISwipeGestureRecognizer* swipeUpRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipe:)];
//	[swipeUpRecognizer setDirection:UISwipeGestureRecognizerDirectionUp];
//	[self.view addGestureRecognizer:swipeUpRecognizer];
//	[swipeUpRecognizer release];
//	
//	UISwipeGestureRecognizer* swipeDownRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipe:)];
//	[swipeDownRecognizer setDirection:UISwipeGestureRecognizerDirectionDown];
//	[self.view addGestureRecognizer:swipeDownRecognizer];
//	[swipeDownRecognizer release];
    
//    UIBarButtonItem *btnMail=[[UIBarButtonItem alloc] initWithTitle:@"@" style:UIBarButtonItemStyleBordered target:self action:nil];
//    self.navigationItem.rightBarButtonItem=btnMail;
//    [btnMail release];
        
    [self.view bringSubviewToFront:mToolbar];
    [mToolbar setHidden:YES];
    [self.slider setDisplayMode:BJRSWPAudioSetTrimMode];  
    

    
}

- (void)gotoLogfile{
    logfile *objlog=[[logfile alloc]initWithNibName:@"logfile" bundle:nil];
    [self.navigationController pushViewController:objlog animated:YES];
    [objlog release];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    if (logback) {
        logback=FALSE;
       
        return;
    }   
    
    if (![self CheckInternetConnectivity]) {
        UIAlertView *objAlert=[[UIAlertView alloc]initWithTitle:@"IQMedia" message:@"No Internet Connection" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [objAlert show];
        [objAlert release]; 
        
        return;
    }
    
     
    if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"url"] length]!=0) {

        if (openURL) {
            openURL=FALSE;
            
            //[logarry addObject:@"Web Service Call for Movie LINK"];
            
            data=[objGlobal WebServiceCalling:@"" :@"" :TAG_URL];
            NSLog(@"respone%@",data);
            
            if ([[[data valueForKey:TAG_HasException] objectAtIndex:0] isEqualToString:@"true"]) {
                UIAlertView *objAlert=[[UIAlertView alloc]initWithTitle:@"IQMedia" message:AlertHasExp delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                objAlert.tag=1000;
                [objAlert show];
                [objAlert release]; 
                return;
            }
            
            if ([[[data valueForKey:TAG_OldVersion] objectAtIndex:0] isEqualToString:@"true"]) {
                UIAlertView *objAlert=[[UIAlertView alloc]initWithTitle:@"IQMedia" message:AlertNewVersion delegate:self cancelButtonTitle:@"Update" otherButtonTitles:@"Cancel",nil];
                objAlert.tag=2000;
                [objAlert show];
                [objAlert release]; 
                return;
            }
            
            [self videoLinkPassToPlay];
            
        }                
    }
               
}

- (void)videoLinkPassToPlay{
    if ([[[data valueForKey:TAG_MediaValid] objectAtIndex:0] isEqualToString:@"true"]) {
        NSString *videoURL= [[data valueForKey:TAG_Media] objectAtIndex:0];
        videoURL=[videoURL stringByAppendingFormat:@".m3u8"];
        NSLog(@"%@",videoURL);
        loadLogFrist=FALSE;
        videoPlayer.contentURL=[NSURL URLWithString:videoURL];
        [videoPlayer prepareToPlay];
        [videoPlayer play];                
        
    } else {
        UIAlertView *objAlert=[[UIAlertView alloc]initWithTitle:@"IQMedia" message:AlertClipID delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];            
        [objAlert show];
        [objAlert release]; 
        videoPlayer.contentURL=nil;                
        return;        
    }
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if (alertView.tag==2000) {
        if (buttonIndex==0) {
            NSString *str=[[data valueForKey:TAG_UpdateUrl] objectAtIndex:0];
            
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
        }else{
            [self videoLinkPassToPlay];
        }
    }
}


- (void)logsendtoServer{
    //[logarry addObject:@"Web Service Call for LOG"];
    NSArray *dt=[objGlobal WebServiceCalling:@"" :@"" :TAG_logURL];
    NSLog(@"respone%@",dt);
    
}

- (void)viewWillDisappear:(BOOL)animated {
	
    [videoPlayer pause];
    [super viewWillDisappear:animated];
    
}
-(void)viewDidDisappear:(BOOL)animated{

} 

- (void)viewDidUnload {
    slider=nil;
    videoPlayer=nil;
    mToolbar=nil;
}
- (void)dealloc {
    [super dealloc];
    [videoPlayer release];
    [slider release];
    [mToolbar release];
}
#pragma mark- MoviePlayer Method
- (void)movieFinish:(NSNotification *)notification{
    
    NSLog(@"Finish");
}


- (void)moviePlaybackComplete:(NSNotification *)notification{
    
    
    if ([videoPlayer loadState] == MPMoviePlaybackStatePaused){
        
        NSLog(@"Paused");
        
    }else if ([videoPlayer loadState] == MPMoviePlaybackStatePlaying){
        
        NSLog(@"Playing");
        
        if (!loadLogFrist) {
            loadLogFrist=TRUE;
            [self performSelectorInBackground:@selector(logsendtoServer) withObject:nil];
        }        
        
        if (self.slider.maxValue==0.0) {
            float movTime=[videoPlayer duration];
            self.slider.maxValue=movTime;
                        
            [self.slider setRightValue:movTime];
                       
        }
        
    }else if ([videoPlayer loadState] == MPMoviePlaybackStateStopped){
        
        if (!loadFalseFrist) {
            loadFalseFrist=TRUE;            
            
        }
        
        NSLog(@"Stopped");
        
    }else if ([videoPlayer loadState] == MPMoviePlaybackStateInterrupted){
        
        NSLog(@"Interrupted");
        
    }else if ([videoPlayer loadState] == MPMoviePlaybackStateSeekingBackward){
        
        NSLog(@"Backward");
        
    }else if ([videoPlayer loadState] == MPMoviePlaybackStateSeekingForward){
        
        NSLog(@"Forward");
        
    }       
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations.
    objOrientation=interfaceOrientation;
    
    if ((UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)) {
        if (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight) {
            if ([[self navigationController] isNavigationBarHidden]) {
                videoPlayer.view.frame=CGRectMake(0, 0, 1024, 768);
            }else{
                videoPlayer.view.frame=CGRectMake(0, 0, 1024, 704);
            }
            slider.eNolbl.frame=CGRectMake(mToolbar.frame.size.width-130, 0, 50, 20); 
        }else{
            
            if ([[self navigationController] isNavigationBarHidden]) {
                videoPlayer.view.frame=CGRectMake(0, 0, 768, 1024);
            }else{
                videoPlayer.view.frame=CGRectMake(0, 0, 768, 960);
            }
            slider.eNolbl.frame=CGRectMake(mToolbar.frame.size.width-130, 0, 50, 20);
        }
    } else {
        if (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight) {
            if ([[self navigationController] isNavigationBarHidden]) {
                videoPlayer.view.frame=CGRectMake(0, 0, 480, 320);
            }else{
                videoPlayer.view.frame=CGRectMake(0, 0, 480, 276);
            }
            slider.eNolbl.frame=CGRectMake(mToolbar.frame.size.width-90, 0, 50, 20);         
            
        }else{
            if ([[self navigationController] isNavigationBarHidden]) {
                videoPlayer.view.frame=CGRectMake(0, 0, 320, 480);
            }else{
                videoPlayer.view.frame=CGRectMake(0, 0, 320, 416);
            }
            slider.eNolbl.frame=CGRectMake(mToolbar.frame.size.width-90, 0, 50, 20);
            
        }
    }   
    
	return YES;
}

- (void)handleSwipe:(UISwipeGestureRecognizer *)gestureRecognizer
{
	UIView* view = [self view];
	UISwipeGestureRecognizerDirection direction = [gestureRecognizer direction];
	CGPoint location = [gestureRecognizer locationInView:view];
	
	if (location.y < CGRectGetMidY([view bounds]))
	{
		if (direction == UISwipeGestureRecognizerDirectionUp)
		{
			[UIView animateWithDuration:0.2f animations:
             ^{
                 
                 if ((UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)) {
                     if (objOrientation == UIInterfaceOrientationLandscapeLeft || objOrientation == UIInterfaceOrientationLandscapeRight) {
                         videoPlayer.view.frame=CGRectMake(0, 0, 1024, 768);
                     }else{
                         videoPlayer.view.frame=CGRectMake(0, 0, 768, 1024);
                     }
                 }else{
                     if (objOrientation == UIInterfaceOrientationLandscapeLeft || objOrientation == UIInterfaceOrientationLandscapeRight) {
                         videoPlayer.view.frame=CGRectMake(videoPlayer.view.frame.origin.x, videoPlayer.view.frame.origin.y, videoPlayer.view.frame.size.width, 276+44);
                     }else{
                         videoPlayer.view.frame=CGRectMake(videoPlayer.view.frame.origin.x, videoPlayer.view.frame.origin.y, videoPlayer.view.frame.size.width, 416+64);
                     }
                 }
                 
                 [[self navigationController] setNavigationBarHidden:YES animated:YES];
             } completion:
             ^(BOOL finished)
             {
                 [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
             }];
		}
		if (direction == UISwipeGestureRecognizerDirectionDown)
		{
            
			[UIView animateWithDuration:0.2f animations:
             ^{
                 [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationSlide];
             } completion:
             ^(BOOL finished)
             {
                 if ((UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)) {
                     if (objOrientation == UIInterfaceOrientationLandscapeLeft || objOrientation == UIInterfaceOrientationLandscapeRight) {
                         videoPlayer.view.frame=CGRectMake(0, 0, 1024, 704);
                     }else{
                         videoPlayer.view.frame=CGRectMake(0, 0, 768, 960);
                     }
                 }else{
                     if (objOrientation == UIInterfaceOrientationLandscapeLeft || objOrientation == UIInterfaceOrientationLandscapeRight) {
                         videoPlayer.view.frame=CGRectMake(0, 0, videoPlayer.view.frame.size.width, 276);
                     }else{
                         videoPlayer.view.frame=CGRectMake(videoPlayer.view.frame.origin.x, videoPlayer.view.frame.origin.y, videoPlayer.view.frame.size.width, 416);
                     }       
                 }
                 
                 [[self navigationController] setNavigationBarHidden:NO animated:YES];
             }];
		}
	}
	else
	{
        
        if (direction == UISwipeGestureRecognizerDirectionDown)
		{
            if (![mToolbar isHidden])
			{
				[UIView animateWithDuration:0.2f animations:
                 ^{
                     [mToolbar setTransform:CGAffineTransformMakeTranslation(0.f, CGRectGetHeight([mToolbar bounds]))];
                 } completion:
                 ^(BOOL finished)
                 {
                     [mToolbar setHidden:YES];
                 }];
			}
		}
		else if (direction == UISwipeGestureRecognizerDirectionUp)
		{
            if ([mToolbar isHidden])
			{
				[mToolbar setHidden:NO];
				
				[UIView animateWithDuration:0.2f animations:
                 ^{
                     [mToolbar setTransform:CGAffineTransformIdentity];
                 } completion:^(BOOL finished){}];
			}
		}    
    }
}

#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc that aren't in use.
}

@end

